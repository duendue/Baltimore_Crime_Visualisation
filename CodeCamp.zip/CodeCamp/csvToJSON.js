const fs = require('fs');

function csvToJSON(fileName, callback) {
console.log("Running first!");
    let data = fs.readFile(fileName, "utf8", function(err, data){
        if(err){
            console.log(err)
        }else{
            let dataLine = data.split("\n");
            let dataArray = [];

            for(let i = 0; i < data.length; i++) {
                dataArray.push(dataLine[i]);
            }

            fs.writeFileSync("udvalg.json", dataArray);
        }
        callback("udvalg.json")
    })
}

csvToJSON("baltimore-crime.csv", function(filename){
    console.log("Running second!");
    let data = fs.readFileSync(filename, "utf8");
    let dataString = JSON.stringify(data, null, 2);
    let dataLine = data.split("\r");

    let emptyArray = [];

    for(let dataObject of dataLine){
        let dataArray = dataObject.split(",");

        dataObject = {
            CrimeDate : dataArray[1],
            CrimeTime : dataArray[2],
            CrimeCode : dataArray[3],
            Location : dataArray[4],
            Description : dataArray[5],
            InsideOutside : dataArray[6],
            Weapon : dataArray[7],
            Post : dataArray[8],
            District : dataArray[9],
            Neighborhood : dataArray[10],
            Latitude : dataArray[11],
            Longitude : dataArray[12],
            Premise : dataArray[13],
            Total_Incidents : dataArray[14]
        };

        emptyArray.push(dataObject);
    }

    let dataStringify = JSON.stringify(emptyArray, null, 2);


    fs.writeFileSync("udvalg.json", dataStringify);
});


