const fs = require('fs');
let data = fs.readFileSync("udvalg.json", "utf8");
data = JSON.parse(data);

function AreaCrime(neighborhood){
    let crimeCount = 0;
    for(let i = 0; i < data.length; i++){
        if(neighborhood === data[i].Neighborhood){
            crimeCount++
        }
    }
    console.log("There was " + crimeCount + " accounts of crime in: " + neighborhood);
}

function BurglaryAmount(neighborhood){
    let crimeCount = 0;
    for(let i = 0; i < data.length-1; i++){
        let date = data[i].CrimeDate.split("/");
        date = date.splice(2);
        if(neighborhood === data[i].Neighborhood && date == 16 && data[i].Description === "BURGLARY"){
            crimeCount++;
        }
    }
    console.log("There was " + crimeCount + " accounts of Burglary in " + neighborhood + " in 2016");
}

function SafestArea(area){

    let areaLocation = [];
    let dayTimeCrime = [];
    let uniqueNeighborhood = [];
    let crimeMap = new Map();

    for(let i = 0; i < data.length; i++){
        if(data[i].InsideOutside === area) {
            areaLocation.push(data[i]);
        }
    }

    for(let i = 0; i < areaLocation.length; i++){

        let time = areaLocation[i].CrimeTime;
        time = time.split(":");
        let hour = time[0];
        let minute = time[1];

        let interval = ((60 * 60 * hour) + (60 * minute));

        if(interval >= 28800 && interval <= 64800){
            dayTimeCrime.push(areaLocation[i])
        }
    }

    for(let i = 0; i < dayTimeCrime.length; i++) {
        if (uniqueNeighborhood.indexOf(dayTimeCrime[i].Neighborhood) < 0) {
            uniqueNeighborhood.push(dayTimeCrime[i].Neighborhood);
        }
    }

    for(let i = 0; i < uniqueNeighborhood.length; i++){
        let crimeCount = 0;
        for(let j = 0; j < dayTimeCrime.length; j++){
            if(dayTimeCrime[j].Neighborhood === uniqueNeighborhood[i]){
                crimeCount++;
            }
        }
        crimeMap.set(uniqueNeighborhood[i], crimeCount);
    }

    let topNeighborhoods = [];
    topNeighborhoods.push(...crimeMap.entries());
    topNeighborhoods.sort(function(a, b){
        return a[1] - b[1]
    });

    topNeighborhoods = topNeighborhoods.slice(0, 10);
    let safeCrimeMap = new Map(topNeighborhoods);

    console.log(safeCrimeMap);
    console.log(uniqueNeighborhood.length);

}

function DistrictCrime(district) {
    let crimeYearMap = new Map();
    let uniqueYears = [];

    for (let i = 1; i < data.length - 1; i++) {
        let year = data[i].CrimeDate
        year = year.split("/");
        year = year.splice(2);


        if (uniqueYears.indexOf(year[0]) < 0) {
            uniqueYears.push(year[0]);
        }

    }


    for (let i = 0; i < uniqueYears.length; i++) {
        let crimeCount = 0;
        for (let j = 0; j < data.length; j++) {
            let year = data[j].CrimeDate;
            year = year.split("/");
            year = year.splice(2);

            if (district === data[j].District && uniqueYears[i] === year[0]) {
                crimeCount++;
            }
        }
        crimeYearMap.set(uniqueYears[i], crimeCount);
    }
    console.log(" ");
    console.log("This was the amount of crime in the district in the corresponding years:");
    console.log(crimeYearMap);
}

switch(process.argv[3]){
    case "AreaCrime":
        AreaCrime(process.argv[2]);
        break;
    case "BurglaryAmount":
        BurglaryAmount(process.argv[2]);
        break;
    case "SafestArea":
        SafestArea(process.argv[2]);
        break;
    case "DistrictCrime":
        DistrictCrime(process.argv[2]);
        break;
}